# coding=utf-8
#   Author: jackyspy
#   Year: 2014
#
#   Distributed under the terms of the GPL (GNU Public License)
#
#   UliPad is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
import re
import traceback
import functools
from urlparse import parse_qsl

from .. import Parser, ErrorNo, handle_exception
from .. import cache
from ..util import (copy_dict_value, in_xbmc, DictCombiner, USER_AGENT)
from lib.bdyun_api import (
    get_feed_sharelist, get_album_list, get_album_listfile, get_share_list,
    get_share_download, parse_pan_url, parse_pan_html, get_bdclnd,
    fetch_url_with_cookies,
    PAGE_SIZE, SHARE_LIST_SIZE, CaptchaError, ShareUrlCancelled,
    parse_inbox_url, get_inbox_unpanfileinfo, get_inbox_download,
    parse_inbox_mobile_url,
)
from lib.colors import NEXT_PAGE_LINK


_RE_LIST = map(re.compile, [
    r'(http://)?(pan|yun)\.baidu\.com/share/(link|home)\?',
    r'(http://)?(pan|yun)\.baidu\.com/s/[0-9a-zA-Z]{2}',
    r'(http://)?(pan|yun)\.baidu\.com/pcloud/album/(info|file)?',
    r'(http://)?(pan|yun)\.baidu\.com/wap/(share/home|link|shareview|album/(file|info))?',  # noqa
    r'(http://)?(pan|yun)\.baidu\.com/inbox/i/[0-9a-zA-Z]{2}',
])


XBMC_HEADERS = '|User-Agent=' + USER_AGENT + '&Referer=http%3A//pan.baidu.com/'


def handle_parse_result(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        res = f(*args, **kwargs)

        if 'file' in res and isinstance(res['file']['link'], basestring):
            # try:
            #     _, _, link = fetch_url_with_headers(
            #         res['file']['link'],
            #         headers={'Referer': 'http://pan.baidu.com/'},
            #         headers_only=True)

            #     res['file']['link'] = link

            # except:
            #     pass
            res['file']['link'] += XBMC_HEADERS

        elif 'list' in res:
            for item in res['list']:
                if isinstance(item['link'], basestring):
                    item['link'] += XBMC_HEADERS

        return res

    return wrapper


class BaiduYunParser(Parser):
    name = 'baiduyun'
    domains = ['pan.baidu.com', 'yun.baidu.com']
    icon = 'http://s2.pan.bdstatic.com/res/static/images/favicon.ico'
    _fn_get_captcha = None

    if in_xbmc:
        def _fn_get_input(self, heading='', default='', hidden=False):
            import xbmc

            kb = xbmc.Keyboard(default, heading, hidden)

            xbmc.sleep(1000)

            kb.doModal()

            if (kb.isConfirmed()):
                return kb.getText()

    else:
        _fn_get_input = None

    def set_get_captcha_func(self, func):
        self._fn_get_captcha = func

    def set_get_input_func(self, fn):
        self._fn_get_input = fn

    def match(self, uri):
        return any(r.match(uri) for r in _RE_LIST)

    @handle_exception
    @handle_parse_result
    def parse(self, uri, params=None):
        if params:
            return self._parse_by_params(uri, params)

        if _RE_LIST[0].match(uri):
            return self._parse_by_shareid(uri)
        elif _RE_LIST[1].match(uri):
            return self._parse_by_s(uri)
        elif _RE_LIST[2].match(uri):
            return self._parse_by_album(uri)
        elif _RE_LIST[4].match(uri):
            # return self._parse_by_inbox(uri)
            return self._parse_by_inbox_mob(uri)

    def _parse_by_inbox(self, uri):
        try:
            return self._parse_by_params(uri, {
                'inbox_params': copy_dict_value(
                    parse_inbox_url(uri),
                    strict_keys=['session_id', 'founder_uk', 'bdstoken']
                )
            })

        except ShareUrlCancelled as e:
            self.raise_exc(
                e.reason, ErrorNo.InvalidUri)

    def _parse_by_inbox_mob(self, uri):

        def create_reacord(r, isdir=False):
            if not isdir:
                return copy_dict_value(api_res, keys=['title', 'thumb', ('dlink', 'link')])

            return {
                'isdir': r['isdir'],
                'title': r['title'],
                'link': {
                    'uri': uri.partition('?')[0] + '?object_id=%(object_id)s&fs_id=%(fs_id)s' % r,
                    'parser': self.name,
                },
            }

        def create_next_page_link():
            if 'page=' in uri:
                next_uri = re.sub(
                    r'page=\d+', 'page=%s' % api_res['next_page'], uri)
            else:
                next_uri = uri + '&page=%s' % api_res['next_page']

            return {
                'isdir': 1,
                'title': u'下一页 >',
                'color': 'FFFF00',
                'link': {
                'uri': next_uri,
                'parser': self.name,
                },
            }

        try:
            api_res = parse_inbox_mobile_url(uri)

            if api_res['type'] == "file":
                if api_res['dlink'] == 'null':
                    raise ShareUrlCancelled(u'文件过期')

                return {'file': create_reacord(api_res)}

            item_list = [create_reacord(r, True) for r in api_res['list']]

            # 增加 下一页
            if 'next_page' in api_res:
                item_list.append(create_next_page_link())

            return {'list': item_list}

        except ShareUrlCancelled as e:
            self.raise_exc(
                e.reason, ErrorNo.InvalidUri)

    def _parse_by_s(self, uri):

        def create_params_dir(api_res, anchor):
            if anchor.startswith('dir/path='):
                path = anchor[9:].rstrip()
            else:
                path = api_res['list'][0]['path']

            return {
                'uk': api_res['uk'],
                'shareid': api_res['shareid'],
                'path': path,
            }

        def create_params_file(api_res):
            return copy_dict_value(
                api_res,
                keys=['title', 'thumb'],
                strict_keys=[
                    'uk', 'shareid', ('fs_id', 'fid')],
            )

        def create_params():
            if api_res['type'] == 'dir':
                params = create_params_dir(api_res, anchor)
            else:
                params = create_params_file(api_res)

            copy_dict_value(dict(parse_qsl(param_str)), params, ['passwd'])

            return params

        def create_record(r, params):
            nr = self._create_record(r, params)

            copy_dict_value(dict(parse_qsl(param_str)), nr, ['passwd'])

            if uri:
                nr['link']['uri'] = uri

            return nr

        url_noanchor, _, anchor = uri.partition('#')
        base_url, _, param_str = url_noanchor.partition('?')

        api_res = self._parse_pan_url(base_url)
        if api_res['type'] == 'dir' and len(api_res['list']) > 1:
            return {'list': [
                    create_record(r, api_res) for r in api_res['list']]}

        return self._parse_by_params(base_url, create_params())

    def _parse_pan_url(self, url, bdclnd=None):
        try:
            return parse_pan_url(url, bdclnd)

        except ShareUrlCancelled as e:
            self.raise_exc(
                e.reason, ErrorNo.InvalidUri, e,
                {'url': url, 'exc_info': traceback.format_exc()})

        except Exception as e:
            self.raise_exc(
                u'URL不存在或解析失败！', ErrorNo.InvalidUri, e,
                {'url': url, 'exc_info': traceback.format_exc()})

    def _parse_by_album(self, uri):
        params = dict(parse_qsl(uri[uri.index('?') + 1:]))

        new_params = {'type': 'album'}

        try:
            copy_dict_value(params, new_params, strict_keys=['uk', 'album_id'])
        except KeyError as e:
            self.raise_exc(u'参数不足', ErrorNo.NotEnoughParameters, e)

        if 'fsid' in params:
            new_params['fid'] = params['fsid']

        if 'page' in params:
            new_params['page'] = int(params['page'])

        return self._parse_by_params(uri, new_params)

    def _parse_by_shareid(self, uri):
        base_url, _, anchor = uri.partition('#')
        params = dict(parse_qsl(base_url[base_url.index('?') + 1:]))

        try:
            new_params = {'uk': params['uk']}
        except KeyError as e:
            self.raise_exc(u'参数不足', ErrorNo.NotEnoughParameters, e)

        copy_dict_value(params, new_params, ['shareid', 'fid', 'passwd'])

        if anchor.startswith('dir/path='):
            new_params['path'] = anchor[9:].rstrip()

        if params.get('view') == 'album':
            new_params['type'] = 'album'

        if 'page' in params:
            new_params['page'] = int(params['page'])

        return self._parse_by_params(base_url, new_params)

    def _parse_by_params(self, uri, params):
        assert 'uk' in params or 'inbox_params' in params

        if params.get('type') == 'album':
            if 'album_id' in params:
                if 'fid' in params:
                    return self._parse_album_fid(uri, params)

                return self._parse_list_album_files(uri, params)

            return self._parse_list_albums(uri, params)

        if 'inbox_params' in params:
            if params['inbox_params'].get('isdir', 1) == 0:
                return self._parse_inbox_fid(uri, params)

            return self._parse_inbox_list(uri, params)

        if 'shareid' in params:
            if 'fid' in params:
                return self._parse_share_fid(uri, params)

            return self._parse_share_list(uri, params)

        return self._parse_feed_sharelist(uri, params)

    def _parse_inbox_list(self, uri, params):

        def create_record(r, params):
            if r['isdir'] == 1:
                return {
                    'isdir': 1,
                    'icon': 'folder',
                    'title': r['server_filename'],
                    'link': {
                        'params': {
                            'inbox_params': copy_dict_value(
                                params, r, ['session_id', 'founder_uk'])
                        },
                        'parser': self.name
                    },
                }

            nr = {
                'title': r['server_filename'],
                'link': {
                    'params': {
                        'inbox_params': {
                            'session_id': params['session_id'],
                            'founder_uk': params['founder_uk'],
                            'object_id': r['object_id'],
                            'fs_id': r['fs_id'],
                            'isdir': 0,
                        },
                        'title': r['server_filename'],
                    },
                    'parser': self.name
                },
            }

            if 'thumbs' in r:
                copy_dict_value(r['thumbs'], nr, [('url1', 'thumb')])

            return nr

        p = params['inbox_params']

        return {'list': [create_record(r, p)
                         for r in get_inbox_unpanfileinfo(**p)['list']]}

    def _parse_inbox_fid(self, uri, params):
        p = params['inbox_params']
        item = copy_dict_value(params, keys=['title', 'thumb', 'icon'])
        item['link'] = get_inbox_download(p['session_id'], p['founder_uk'],
                                          p['object_id'], p['fs_id'])['url']

        return {'file': item}

    def _parse_share_fid(self, uri, params):

        def get_sign_timestamp():
            sign, timestamp = cache.get(
                'bdyun.sign_timestamp.' + params['shareid']
            ) or (None, None)

            if not sign or not timestamp:

                if uri:
                    url = self._complete_shorturl(uri)
                else:
                    url = 'http://yun.baidu.com/share/link?uk=%s&shareid=%s&fid=%s' % (  # noqa
                        params['uk'], params['shareid'], params['fid'])

                api_res = self._parse_pan_url(url, bdclnd)

                sign = api_res.get('sign')
                timestamp = api_res.get('timestamp')

            return sign, timestamp

        def get_dlink():
            cached_link = cache.get('bdyun.fid_dlink.' + str(params['fid']))
            if cached_link:
                return cached_link

            sign, timestamp = get_sign_timestamp()

            try:
                return get_share_download(
                    params['uk'], params['shareid'], params['fid'], sign,
                    timestamp, fn_get_captcha=self._fn_get_captcha,
                    bdclnd=bdclnd)

            except CaptchaError as e:
                if e.reason == 'WrongCaptcha':
                    self.raise_exc(u'验证码不正确！', ErrorNo.WrongCaptcha)

        bdclnd = cache.get('bdyun.bdclnd.' + params['shareid'])

        dlink = get_dlink()
        if not dlink:
            return

        item = copy_dict_value(params, keys=['title', 'thumb', 'icon'])
        item['link'] = dlink

        return {'file': item}

    def _parse_share_list(self, uri, params):

        def create_record(r, params):
            nr = self._create_record(r, params)

            copy_dict_value(params, nr, ['passwd'])

            if uri:
                nr['link']['uri'] = uri

            return nr

        def parse_page():
            if uri and 'passwd' not in params:
                url = self._complete_shorturl(uri)
            else:
                url = 'http://yun.baidu.com/share/link?uk=%s&shareid=%s' % (
                    params['uk'], params['shareid'])

            bdclnd = _get_bdclnd()
            if bdclnd:
                headers = {'Cookie': 'BDCLND=' + bdclnd}
            else:
                headers = None

            content, _, u = fetch_url_with_cookies(url, headers=headers)
            if '/share/init?' not in u:
                try:
                    return parse_pan_html(content)

                except ShareUrlCancelled as e:
                    self.raise_exc(
                        e.reason, ErrorNo.InvalidUri, e, {'url': url})

                except Exception as e:
                    self.raise_exc(
                        u'URL不存在或解析失败！', ErrorNo.InvalidUri, e, {'url': url})

            # 需要输入密码
            if not self._fn_get_input:
                self.raise_exc(u'您访问的页面需要提取密码！', ErrorNo.WrongPassword)

            for i in range(3):
                passwd = self._fn_get_input(u'请输入提取密码：')
                if not passwd:
                    self.raise_exc(u'您无权访问该页面！', ErrorNo.WrongPassword)

                bdclnd = get_bdclnd(
                    params['uk'], params['shareid'], passwd)

                if bdclnd:
                    return self._parse_pan_url(url, bdclnd=bdclnd)

            else:
                self.raise_exc(u'连续3次输入错误密码！', ErrorNo.WrongPassword)

        def _get_bdclnd():
            bdclnd = cache.get('bdyun.bdclnd.' + params['shareid'])
            if bdclnd:
                return bdclnd

            if 'passwd' in params:
                bdclnd = get_bdclnd(
                    params['uk'], params['shareid'], params['passwd'])

                if not bdclnd:
                    self.raise_exc(u'您提供的密码不正确！', ErrorNo.WrongPassword)

                return bdclnd

        if 'path' not in params:
            page_info = parse_page()

            if page_info['type'] == 'file':
                params['fid'] = page_info['fs_id']
                params['title'] = page_info['title']

                return self._parse_share_fid(uri, params)

            dlist = page_info['list']
            if len(dlist) > 1:
                return {'list': [create_record(r, params) for r in dlist]}

            path = page_info['list'][0]['path']

        else:
            path = params['path']

        page = max(1, params.get('page', 1))

        api_res = get_share_list(
            params['uk'], params['shareid'], path,
            page=page, bdclnd=_get_bdclnd())

        alist = [create_record(r, params) for r in api_res['list']]

        if api_res['count'] >= SHARE_LIST_SIZE:
            alist.append(self._create_next_page_link(params, page))

        return {'list': alist}

    def _parse_feed_sharelist(self, uri, params):

        def create_record(r, params):
            nr = self._create_record(r, params)

            # path有误，必须重新解析！！！
            nr['link']['params'].pop('path', None)

            if 'shorturl' in r:
                nr['link']['uri'] = r['shorturl']

            return nr

        page = params.get('page', 0)

        api_res = get_feed_sharelist(params['uk'], start=page * PAGE_SIZE)

        alist = [create_record(r, params) for r in api_res['list']]

        if (api_res['count'] + page * PAGE_SIZE < api_res['total_count']):
            alist.append(self._create_next_page_link(params, page))

        return {'list': alist}

    def _parse_list_albums(self, uri, params):

        def create_record(r, params):
            new_params = params.copy()
            new_params.pop('page', None)
            new_params['album_id'] = r['album_id']

            nr = {
                'isdir': 1,
                'title': r['title'],
                'thumb': r['thumb'],
                'link': {
                    'params': new_params,
                    'parser': self.name,
                },
            }

            return nr

        page = params.get('page', 0)

        api_res = get_album_list(params['uk'], start=page * PAGE_SIZE)

        alist = [create_record(r, params) for r in api_res['list']]

        if (api_res['count'] + page * PAGE_SIZE < api_res['total_count']):
            alist.append(self._create_next_page_link(params, page))

        return {'list': alist}

    def _parse_list_album_files(self, uri, params):

        def create_record(r):
            nr = {
                'title': r['title'],
                'link': r['dlink'],
            }

            if 'thumb' in r:
                nr['thumb'] = r['thumb']

            return nr

        page = params.get('page', 0)

        api_res = get_album_listfile(
            params['uk'], params['album_id'], start=page * PAGE_SIZE)

        alist = [create_record(r) for r in api_res['list']]

        if (api_res['count'] + page * PAGE_SIZE < api_res['total_count']):
            alist.append(self._create_next_page_link(params, page))

        return {'list': alist}

    def _create_next_page_link(self, params, curr_page):
        new_params = params.copy()
        new_params['page'] = curr_page + 1

        return {
            'isdir': 1,
            'title': u'下一页',
            'color': NEXT_PAGE_LINK,
            'link': {
                'params': new_params,
                'parser': self.name,
            },
        }

    def _parse_album_fid(self, uri, params):
        url = 'http://yun.baidu.com/pcloud/album/file?album_id=%s&uk=%s&fsid=%s' % (  # noqa
            params['album_id'], params['uk'], params['fid'])

        try:
            api_res = self._parse_pan_url(url)
        except Exception as e:
            self.raise_exc(
                u'URL不存在或解析失败！', ErrorNo.InvalidUri, e, {'url': url})

        item = {
            'title': api_res['title'],
            'link': api_res['dlink'],
        }

        if 'thumb' in api_res:
            item['thumb'] = api_res['thumb']

        return {'file': item}

    def _complete_shorturl(self, shorturl):
        if shorturl.startswith('http://'):
            return shorturl

        return 'http://yun.baidu.com/s/' + shorturl

    def _create_dir_record(self, params):
        return {
            'isdir': 1,
            'icon': 'folder',
            'title': params['title'],
            'link': {
                'params': copy_dict_value(params, keys=['path'],
                    strict_keys=['type', 'uk', 'shareid']),
                'parser': self.name
            },
        }

    def _create_file_record(self, params):
        return {
            'title': params['title'],
            'link': {
                'params': copy_dict_value(
                    params, strict_keys=[
                        'type', 'title', 'uk', 'shareid', ('fs_id', 'fid')]),
                'parser': self.name
            },
        }

    def _create_album_record(self, params):
        return {
            'isdir': 1,
            'icon': 'baiduyun_album',
            'title': params['title'],
            'link': {
                'params': copy_dict_value(params,
                    strict_keys=['type', 'uk', 'album_id']),
                'parser': self.name
            },
        }

    def _create_record(self, *params_list):
        params = DictCombiner(*params_list)

        res = {
            'file': self._create_file_record,
            'dir': self._create_dir_record,
            'album': self._create_album_record,
        }[params['type']](params)

        copy_dict_value(params, res, ['thumb'])

        return res
