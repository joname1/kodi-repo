# coding=utf-8
#   Author: jackyspy
#   Year: 2014
#
#   Distributed under the terms of the GPL (GNU Public License)
#
#   UliPad is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
import os
import re
import string

from .. import Parser, handle_exception, man
from ..util import fetch_url, chardet, in_xbmc

if in_xbmc:
    import xbmcvfs


class BTHParser(Parser):
    name = 'bth'
    icon = 'bth'
    protocols = ['bth']

    @handle_exception
    def parse(self, uri, params=None):
        if uri.startswith('bth:'):
            uri = uri[4:]

        lines = self.read_btih_file(uri)
        if lines is None:
            return

        return {'list': filter(None, map(self._parse_line, lines))}

    def _parse_line(self, line):
        if line[0] == '#':
            return

        url, _, name = line.rpartition('|')
        url = url.rstrip()
        name = name.lstrip()

        if url == '':
            if name == '':
                return

            url, name = name, ''

        parser = man.find_match_parser(url)
        if parser:
            return parser.get_entry(url, {'title': name})

        return {
            'title': name or url,
            'link': url,
        }

    def get_entry(self, uri, params=None):
        return {
            'isdir': 1,
            'title': uri,
            'icon': self.icon,
            'link': {
                'uri': uri,
                'parser': self.name,
            },
        }

    def _read_bth_content(self, bthfile):
        protocol, _, url_path = bthfile.partition('://')
        if not url_path:
            protocol, url_path = '', protocol

        if not url_path:
            return

        if protocol in ('http', 'https', 'ftp'):
            return fetch_url(bthfile)

        if protocol in ('smb', 'nfs', 'special'):
            if not in_xbmc:
                return

            return xbmcvfs.File(bthfile).read()

        if protocol and protocol != 'file':
            return

        if in_xbmc:
            if xbmcvfs.exists(url_path):
                return xbmcvfs.File(bthfile).read()

            return

        if os.path.isfile((url_path)):
            return open(url_path).read()

    def _decode_content(self, content):
        match = re.search(r'^#\s*(?:en)?coding\s*[=:]\s*(.\S+)', content)
        if match:
            encoding = match.group(1).upper()
        else:
            encoding = chardet.detect(content)['encoding']

        if encoding in ('GB2312', 'BIG5'):
            content = content.decode(encoding)

        return content

    def read_btih_file(self, bthfile):
        content = self._read_bth_content(bthfile)
        if content is None:
            return

        if len(content) == 0:
            return []

        return filter(None, map(string.strip,
                                self._decode_content(content).splitlines()))
