# coding=utf-8
#   Author: jackyspy
#   Year: 2014
#
#   Distributed under the terms of the GPL (GNU Public License)
#
#   UliPad is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
import functools
import traceback

from .manager import ParserManager

try:
    from third_party import enum
except ImportError:
    import enum  # noqa


man = ParserManager()


class ParserMeta(type):
    _parser_base_class = None

    def __init__(cls, name, bases, dict):
        super(ParserMeta, cls).__init__(name, bases, dict)

        if ParserMeta._parser_base_class is None:

            if name == 'Parser':
                ParserMeta._parser_base_class = cls

        elif ParserMeta._parser_base_class in bases:
            if not getattr(cls, 'name', None):
                setattr(cls, 'name', name)

            instance = super(ParserMeta, cls).__call__()
            cls._instance = instance
            man.register_parser(instance)

    def __call__(cls, *args, **kw):
        return cls._instance


class Parser:
    __metaclass__ = ParserMeta

    icon = None
    check_match = False

    def match(self, uri):
        return False

    def get_entry(self, uri, params=None):
        res = {
            'isdir': 1,
            'title': params.get('title') or uri,
            'link': {
                'uri': uri,
                'parser': self.name,
            },
        }

        if self.icon:
            res['icon'] = self.icon

        return res

    def parse(self, uri, params=None):
        raise NotImplementedError

    def __str__(self):
        return self.name or self.__class__.__name__

    def raise_exc(self, errmsg, errno, orig_exc=None, extra_data=None):
        raise ParserError(
            errmsg, errno or ErrorNo.UserDefined, self, orig_exc, extra_data)


class ParserError(Exception):
    __slots__ = ('errmsg', 'errno', 'parser', 'exc', 'data')

    def __init__(self, errmsg, errno, parser, orig_exc=None, extra_data=None):
        self.errmsg = errmsg
        self.errno = errno
        self.parser = parser
        self.exc = orig_exc
        self.data = extra_data or {}

    def __str__(self):
        data = self.data.copy()
        exc_info = data.pop('exc_info', '')

        return '''%s Error(%s): %s
        Original Exception: %s
        Extra Data: %s
        %s''' % (self.parser, self.errno, self.errmsg,
               repr(self.exc), repr(data), exc_info)


def handle_exception(f):
    @functools.wraps(f)
    def wrapper(self, *args, **kwargs):
        try:
            return f(self, *args, **kwargs)
        except (ParserError, KeyboardInterrupt):
            raise
        except Exception as e:
            data = {'func': f.__name__, 'args': args, 'kwargs': kwargs,
                    'exc_info': traceback.format_exc()}
            self.raise_exc(u'未捕获异常', ErrorNo.Unknown, e, data)

    return wrapper


ErrorNo = enum.Enum('ErrorNo', 'Unknown UserDefined InvalidUri NotEnoughParameters WrongCaptcha WrongPassword')  # noqa
