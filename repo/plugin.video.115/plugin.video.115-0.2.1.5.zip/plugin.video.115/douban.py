import urllib,urllib2,gzip
from StringIO import StringIO

def _http(url, data=None,referer=None):
	"""
	open url
	"""
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	req.add_header('Accept-encoding', 'gzip,deflate')
	req.add_header('Accept-Language', 'zh-cn')
	if referer:
		req.add_header('Referer', referer)
	if data:
		rsp = urllib2.urlopen(req, data=data, timeout=15)
	else:
		rsp = urllib2.urlopen(req, timeout=15)
	if rsp.info().get('Content-Encoding') == 'gzip':
		buf = StringIO(rsp.read())
		f = gzip.GzipFile(fileobj=buf)
		data = f.read()
	else:
		data = rsp.read()
	rsp.close()
	return data