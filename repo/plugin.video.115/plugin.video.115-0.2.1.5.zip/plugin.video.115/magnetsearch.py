import urllib,urllib2,re,xbmcplugin,xbmcgui,subprocess,sys,os,os.path,sys,xbmcaddon,xbmcvfs,random,hashlib,threading,httplib,ssl,socket
import json,cookielib,gzip,time
import xbmc

from bt import TorrentFile
from xbmcswift2 import Plugin, CLI_MODE, xbmcaddon,ListItem,actions
from StringIO import StringIO
from zhcnkbd import Keyboard